
from django.contrib import admin
from .models import ErrorLog


admin.site.register(ErrorLog)

