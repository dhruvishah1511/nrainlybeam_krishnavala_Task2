from django.apps import AppConfig


class TasktryConfig(AppConfig):
    name = 'tasktry'
